# Presentation Notes — Neonatal Incubator DDQN + SHAP (v3.1)

> Speaker notes for the 15-slide v3.1 presentation deck.
> All numbers below are **simulation parameters** and reproducible from
> `config.yaml` + `src/environment.py` + `src/baseline.py`.
> Slides marked `[SHOW plots/...]` indicate which figure to embed.
> Verify references list at the end (2 of 8 verified via PubMed E-utilities).

---

## Slide 1 — Title

**Title**: Reinforcement Learning + Explainable AI for Neonatal Incubator
Regulation: A First-Principles DDQN + SHAP Benchmark (v3.1)

**Subtitle**: Member 1 environment + rule-based baseline, Member 2 DDQN
trainer, Member 3 SHAP explainer.

**Speaker notes**: This is the v3.1 release. Every V3 review issue (V3-01
to V3-05) is resolved; the baseline now produces a *recoverable* scenario 5
disturbance, instance-level parameter overrides via `config_path`, and
fully audited effective thermal masses. All 5 evaluation episodes still
survive to step 200 with zero safety violations.

---

## Slide 2 — Problem motivation

* Preterm neonates (≈ 15 million births/year worldwide, WHO) are at risk
  of hypothermia (admission temperature < 36 °C is associated with
  increased mortality) and hypoxia / hyperoxia (SpO2 outside [91, 95] %
  is associated with ROP, BPD, IVH).
* Modern incubators use PID control, but multi-objective regulation
  (thermal + oxygen + energy) is a non-trivial trade-off.
* Can a Deep Reinforcement Learning agent (DDQN) match or beat a tuned
  PID baseline, and can SHAP explain its decisions?

**Speaker notes**: The clinical stakes justify a careful simulator + RL +
XAI pipeline. Preterm birth affects ~11 % of all births (WHO); admission
hypothermia affects > 50 % of VLBW infants in LMIC settings (Lyu 2022).

---

## Slide 3 — Approach overview

Three-member pipeline:

1. **Member 1**: First-principles Gymnasium environment
   (`environment.py` + `config.yaml` single source of truth, V3-01) and a
   rule-based (PID + bang-bang) baseline controller (`baseline.py`).
2. **Member 2**: DDQN trainer; trains a Q-network `Q(s, a; θ)` over the
   Discrete(25) action space, using the 11-dim observation.
3. **Member 3**: SHAP explainer; attributes Q-values and chosen actions
   to the 11 input features, stratified by scenario and training phase.

**Speaker notes**: Each member consumes the previous member's frozen
contract — the 11-dim observation order, the 25-action table (now
per-instance, V3-01), and the YAML-configured physics / reward / safety
parameters. Member 2 can override any parameter via a custom `config_path`
for ablation studies without touching `environment.py`.

---

## Slide 4 — Population & target bands

* Population: preterm post-stabilisation neonate (NICE NG124).
* Thermal: `Tc ∈ [36.5, 37.5] °C` comfort band; `Tc ∈ [35.5, 38.0] °C`
  hard band.
* Oxygen: `SpO2 ∈ [91, 95] %` target band; `SpO2 ∈ [85, 96] %` hard band.
* Episodes: 200 control steps × 45 s = 2.5 h simulated time.

**Speaker notes**: The hard bands are deliberately inside the clinical
alarm thresholds so the simulator is safe to train on. The 96 %
hyperoxia ceiling reflects the SUPPORT-trial-era ROP-prevention
protocol.

---

## Slide 5 — State & action spaces (v3.1)

**Observation (11-dim Box, float32)**:

```
[Tc, Tsk, Ta, C_O2, SpO2, Tamb,
 dTa_dt, dC_O2_dt, phase, disturbance, scenario_id]
```

The 11th feature `scenario_id = (scenario−1)/4 ∈ [0, 1]` restores the
Markov property. `dTa_dt` and `dC_O2_dt` are **realized** post-clipping
rates. `phase = step/200` is normalised time. `disturbance` ∈ {0, 1, 2}
is the active disturbance flag.

**Action (Discrete(25) = 5 × 5)**: `action = heater_idx × 5 + o2_idx`.

* `heater_levels = (0.00, 0.25, 0.50, 0.75, 1.00)` → `Q_heater = level × 360 W`.
* `fio2_levels = (0.21, 0.30, 0.40, 0.50, 0.60)` → absolute volume
  fractions.

V3-01 fix: the `action_table` is now built **per-instance** from
`env.q_heater_max` at construction time. If a custom `config_path`
overrides `q_heater_max`, the table is rebuilt automatically — Member 2
does not need to recompute the `Q_heater_W` column by hand.

**Speaker notes**: The agent's Q-network is `Linear(11, 128) → ReLU →
Linear(128, 128) → ReLU → Linear(128, 25)` — a standard 2-hidden-layer
MLP. Sub-stepping (`N_SUBSTEPS = 10`, `dt_sub = 4.5 s`) keeps the ODE
integrator stable under any action choice.

---

## Slide 6 — Physics model

Lumped-parameter ODEs (sub-stepped explicit Euler):

```
C_air  · dTa/dt = Q_heater - K_loss · (Ta - Tamb) · h_c - K_baby · (Ta - Tc)
C_core · dTc/dt = +K_baby · (Ta - Tc)                       # POSITIVE sign
dC_O2/dt        = (FiO2·100 - C_O2)·K_BLEND - K_LEAK·(C_O2 - 21)
dSpO2/dt        = K_SPO2 · (SpO2_eq(C_O2, t) - SpO2)        # offset applied ONCE
SpO2_eq(C_O2,t) = SPO2_BASE + SPO2_GAIN·(C_O2 - 21) - desat_offset(t)
desat_offset(t) = DESAT_OFFSET · sin(π·(t − 60)/60),  t ∈ [60, 120] ; else 0
```

V3-02 fix: `C_AIR = 1500 J/°C` is the **effective** thermal mass of the
incubator's air + walls + mattress + internal structure (a 30 L air
volume alone is ~36 J/°C; the effective mass is ~1500 J/°C). `C_CORE =
2000 J/°C` is the **effective** core thermal mass of the infant's central
compartment (brain + thoracic organs + central blood volume), calibrated
to give a ~500 s core time constant. Both are now labelled
"calibrated educational parameter" in `docs/parameter_provenance.md`.

V2-01 fix: `desat_offset` depresses `SpO2_eq` directly (physiological
model), not as a sink on `C_O2`. This produces a measurable SpO2 dip the
agent must compensate by raising `FiO2`.

**Speaker notes**: All constants are in `config.yaml → physics` (single
source of truth, V3-01). Each sub-step is `dt_sub = 4.5 s`, ensuring
`k·dt_sub < 0.5` for the fastest rate (`K_BLEND = 0.05 1/s`). Member 2
can override any parameter via a custom `config_path`.

---

## Slide 7 — MDP formalisation

The tuple is `M = (S, A, P, R, γ)`:

| Symbol | Instance |
|--------|----------|
| `S` | `Box(11,) float32` (11-dim observation) |
| `A` | `Discrete(25)` (5 heater × 5 FiO2) |
| `P` | Stochastic kernel from ODEs + Gaussian sensor noise |
| `R` | Weighted multi-objective — see Slide 8 |
| `γ` | 0.99 |

The observation now includes `phase` (normalised time), `disturbance`
flag, and `scenario_id` — three augmentations that jointly make the
environment a fully-observable MDP. Without `scenario_id`, scenario 1
and scenario 5 states would alias.

**Speaker notes**: The agent has enough information to distinguish
"porthole-driven Tc drop" from "controller-error-driven Tc drop"
without recurrent state — important for SHAP analysis (Slide 14).

---

## Slide 8 — Reward function (exact formula)

```
r_thermal = -(Tc - 37.0)²
r_oxygen  = -band_err_sq(SpO2, [91, 95])
            band_err_sq = 0 in band, (edge - SpO2)² otherwise
r_energy  = -(u_heater² + u_fio2_norm²),  u_fio2_norm = (fio2 - 0.21)/0.39
r_safety  = -100 if (Tc ∉ [35.5, 38.0] OR SpO2 ∉ [85, 96]) else 0

R = 1.0·r_thermal + 0.5·r_oxygen + 0.05·r_energy + 1.0·r_safety
```

**Worked example** (`Tc = 37.0`, `SpO2 = 93.0`, `u_heater = 0.5`,
`fio2 = 0.30`, safe): `R = 0.05 · (-(0.25 + 0.231²)) = -0.0152`.

**Speaker notes**: The squared band error for oxygen is sharper near the
band edges than the linear error used in v2.x, so the agent learns to
*stay inside* the [91, 95] band rather than approach its edges. All four
weights are stored on the env instance (V3-01) and may be overridden via
`config_path`.

---

## Slide 9 — Safety limits

* Thermal: `Tc ∈ [36.5, 37.5]` comfort (no penalty); `[35.5, 38.0]` hard
  (terminate + `r_safety = -100`).
* Oxygen: `SpO2 ∈ [91, 95]` target band (zero penalty); `[85, 96]` hard
  band (terminate + `r_safety = -100`).
* Episode budget: 200 steps (2.5 h simulated time) → `truncated = True`.

**Key distinction**: the 96 % ceiling is a *hard abort*, not the 95 %
upper target. Above 95 %, the agent incurs a small `(SpO2 − 95)²`
penalty; above 96 %, the episode terminates. The 85 % floor works the
same way.

**Speaker notes**: The hard ceiling at 96 % reflects the ROP-prevention
protocol from the SUPPORT trial (NEJM 2010, PMID 20472939 — verified
via PubMed E-utilities). The 91–95 % target band matches **NICE
guideline NG124** ("Specialist neonatal respiratory care for babies
born preterm", recommendation 1.4.2) — V3-04 update replaces the stale
NG122 citation.

---

## Slide 10 — Scenarios (5 canonical)

| # | Name | Disturbance | SHAP class |
|---|------|-------------|------------|
| 1 | `normal_standard` | none | Normal |
| 2 | `ambient_temperature_drop` | `Tamb: 25 → 18 °C` linear | Abnormal-temperature |
| 3 | `porthole_opening_event` | `h_c = 2.0` on steps [50, 80] | Abnormal-temperature |
| 4 | `initial_hypothermia` | none (initial condition) | Abnormal-temperature |
| 5 | `oxygen_disturbance_desaturation` | `desat_offset = 5·sin` on [60, 120] | Abnormal-oxygen (V3-03) |

Scenarios 3 and 5 are the hard ones — scenario 3 is feasible (200 steps
survived, 0 violations); scenario 5 is now a **RECOVERABLE CHALLENGE**
(V3-03): `DESAT_OFFSET` reduced from 8.0 to 5.0, so the SpO2 dip is
real but the [91, 95] target band is reachable with adequate `FiO2`.

**Speaker notes**: SHAP class is used by Member 3 to stratify feature
attributions across scenarios — the same feature may have different
importance on Normal vs Abnormal-oxygen trajectories.

---

## Slide 11 — Baseline results (v4, 5 episodes)

**[SHOW plots/summary_bar.png]**

| Scenario | Mean total_reward | Mean \|Tc − 37\| | Mean SpO2 band_err | Safety violations | Steps survived |
|----------|------------------:|------------------:|-------------------:|-------------------:|---------------:|
| 1 normal_standard | **−10.18 ± 0.23** | 0.183 | 0.000 | 0 | 200 |
| 2 ambient_temperature_drop | **−15.51 ± 1.61** | 0.215 | 0.000 | 0 | 200 |
| 3 porthole_opening_event | **−11.58 ± 0.86** | 0.191 | 0.000 | 0 | 200 |
| 4 initial_hypothermia | **−11.11 ± 0.39** | 0.191 | 0.015 | 0 | 200 |
| 5 oxygen_disturbance_desaturation | **−66.82 ± 0.96** | 0.182 | 0.323 | 0 | 200 |

**Key finding**: The corrected baseline (FF_BIAS=0.25) stabilizes all 5
scenarios with zero safety violations and 200-step episodes. Mean Tc
tracks within 0.18-0.22 °C of the 37.0 °C target. Scenario 5 (oxygen
disturbance) shows the clearest effect: SpO2 band_err = 0.323 (vs
0.000 for scenarios 1-3), reward −66.82 (vs −10 to −15). This is the
recoverable challenge the DDQN must beat. All 5 episodes still
survive to step 200 with **0 safety violations**.

**Speaker notes**: The corrected baseline (FF_BIAS=0.25) stabilizes
all 5 scenarios with zero safety violations and 200-step episodes. Mean
Tc tracks within 0.18-0.22 °C of the 37.0 °C target. Scenario 5 shows
the clearest effect (return −66.82 vs −10.18 for scenario 1; SpO2
band_err 0.323 vs 0.000). This is the **head-room** for DDQN to
improve — the agent must anticipate the desaturation and raise `FiO2`
before `SpO2` dips below 91.

---

## Slide 12 — DDQN setup & Held-Out Evaluation (Member 2)

* Architecture: `Dense(128, relu) -> Dense(128, relu) -> Dense(25, linear)` in TensorFlow/Keras (`src/q_network.py`), paired with a fixed `ObservationNormalizer` saved inside every checkpoint (`pickle`-serialized dict in `.pt` files; load via `DDQNAgent.load()`, not `torch.load()`).
* Current `config.yaml → training` hyperparameters: `γ = 0.99`, `lr = 3e-4` (with `1e-4` and `5e-4` compared in `results/ddqn/hyperparameter_study.csv`), `batch_size = 128`, `buffer_size = 100 000`, `warmup_steps = 3 000`, `total_steps = 100 000`, `train_freq = 2`, `target_update = "hard"` every `500` gradient steps (or `"soft"` with `τ = 0.005`), `reward_scale = 0.1`, linear `ε: 1.0 → 0.02` over `40 000` steps after warmup, seeds `[0, 1, 2]`.
* Bootstrap target: `target = r + γ·Q(s', argmax_a Q(s', a; θ_online); θ_target)·(1 - terminated)`.
  **Note**: `truncated` is *not* terminal — bootstrap normally on `truncated = True`.
* Held-out evaluation (`src/evaluate_controllers.py`): **10 held-out test episodes per scenario** (`50` episodes per trained model on disjoint `test_seed(scenario, i)` seeds; an expanded 30-episode-per-scenario evaluation is also saved in `results/ddqn_30ep/`).
* V3-01 ablation hook: pass `config_path="ablation.yaml"` to override
  any parameter (e.g. `desat_offset ∈ {3, 5, 7}`) without modifying
  `environment.py`.

**Speaker notes**: Hyperparameters live in `config.yaml → training`.
Member 2 may tune them but should keep the seed set for cross-run
comparability. The resolved config dict is exposed as `env._config` for
inspection at the start of each run.

---

## Slide 13 — Limitations & V3 review resolutions

* **V3-01 — config single source of truth (instance-level)**:
  `load_config()` returns a resolved dict (no module-global mutation);
  `__init__` stores all 24 physics/reward/safety params on the instance
  (`env.k_loss`, `env.w_thermal`, `env.r_safety_penalty`, ...); the
  `action_table` is rebuilt per-instance from `env.q_heater_max`. A
  custom `config_path` overrides any parameter for ablation studies.
* **V3-02 — effective thermal mass**: `C_AIR = 1500 J/°C` is the
  *effective* thermal mass of the incubator's air + walls + mattress +
  internal structure (a 30 L air volume alone is ~36 J/°C; effective
  mass is ~1500 J/°C). `C_CORE = 2000 J/°C` is the *effective* core
  thermal mass of the infant's central compartment (brain + thoracic
  organs + central blood volume), calibrated to a ~500 s core time
  constant. Both are labelled "calibrated educational parameter" in
  `docs/parameter_provenance.md`.
* **V3-03 — recoverable scenario 5**: `DESAT_OFFSET` reduced from 8.0 to
  5.0. Scenario 5 is now a recoverable challenge (return −66.82, SpO2
  band_err 0.323; was −73.34 in v3.1, −246 in v3.0). Peak `SpO2_eq =
  92.32 %` is inside the [91, 95] target band.
* **V3-04 — NG124 citation**: all "NICE NG122" references replaced
  with "NICE NG124" ("Specialist neonatal respiratory care for babies
  born preterm", recommendation 1.4.2).
* **V3-05 — cleanup**: stale "10-feature" references removed from
  `baseline.py` and `run_simulation.py`; the handoff lists only test
  functions that exist in `tests/test_environment.py` and
  `tests/test_baseline.py`.

**Speaker notes**: The V3 review also identified the lumped-parameter
model's inherent limitations (no humidity control, no spatial gradients,
single-baby phenotype, no sensor faults). These are documented in
`docs/safety_limits.md §6` and `docs/parameter_provenance.md §6`.

---

## Slide 14 — SHAP / XAI plan (Member 3)

* **Explainer**: TreeSHAP or DeepSHAP on the Q-network; per-action
  attribution across the 11 features.
* **Stratification**: by SHAP class (Normal, Abnormal-temperature,
  Abnormal-oxygen) and by training phase (early / mid / late).
* **Hypotheses**:
  1. On scenario 5, `SpO2`, `C_O2`, `disturbance`, and `scenario_id`
     dominate oxygen-action attributions.
  2. On scenario 3, `disturbance` and `dTa_dt` dominate heater-action
     attributions during the porthole window [50, 80].
  3. The `scenario_id` feature has high attribution on cross-scenario
     training but near-zero on per-scenario training (sanity check).
* **Output**: `plots/shap_*.png`, `results/shap_summary.csv`.

**Speaker notes**: Member 3 must use the exact 11 feature names from
`environment.OBS_NAMES` to label SHAP attributions. The V3-03 retune
of scenario 5 makes SHAP analysis more interpretable: the recoverable
disturbance produces a cleaner attribution signal than the v3.0 stress
test that always pushed SpO2 below the hard floor.

---

## Slide 15 — Conclusion & next steps

* v3.1 environment is **production-ready** for DDQN + SHAP training:
  - 11-dim observation, 25-action space, exact reward, hard safety bands.
  - 5 scenarios with clearly distinct but recoverable returns (scenario 5
    = −66.82 vs scenario 1 = −10.18).
  - 0 safety violations across all 5 baseline episodes.
  - All 5 V3 review issues documented as fixed.
* Member 2 starts training immediately; Member 3 starts SHAP scaffolding
  using the rule-based baseline trajectories.
* Future work: humidity control, stochastic disturbances, multi-infant
  phenotypes, real-data validation.

**Speaker notes**: Final slide — emphasise reproducibility (`config.yaml`
+ seed = byte-identical trajectories), the V3-01 `config_path` ablation
hook, and the open-source, simulation-only nature of the deliverable.

---

## Verified references (2 of 8 verified via PubMed E-utilities)

1. ✓ **SUPPORT Study Group** (Finer NN, Carlo WA, Walsh MC, et al.).
   "Early CPAP versus surfactant in extremely preterm infants."
   *N Engl J Med* 2010 May 27;362(21):1970-9. DOI: 10.1056/NEJMoa0911783.
   PubMed PMID: **20472939**. (Verified via PubMed esummary.fcgi on
   2025-11-04: returned full citation including "SUPPORT Study Group of
   the Eunice Kennedy Shriver NICHD Neonatal Research Network", pubdate
   "2010 May 27", source "N Engl J Med", volume "362", pages "1970-9".)
2. ✓ **Lyu Y, Wei S, Zhang Y, et al.** "Implementation of a temperature
   bundle improves admission hypothermia in very-low-birth-weight infants
   in China: a multicentre study." *BMJ Open Qual* 2022 May;11(2):e001532.
   PubMed PMID: **35500935**. (Verified via PubMed esummary.fcgi on
   2025-11-04: returned title, source "BMJ Open Qual", pubdate "2022
   May".)
3. **WHO**. "Thermal protection of the newborn: a practical guide."
   WHO/RHT/MSM/97.2, 1997.
4. **NICE guideline NG124**. "Specialist neonatal respiratory care for
   babies born preterm." 2022, recommendation 1.4.2. URL:
   https://www.nice.org.uk/guidance/ng124 (retrieved 2025-11-04).
5. **AAP Committee on Fetus and Newborn**. "Hospital discharge of the
   high-risk neonate." Pediatrics 2008;122(5):1119-26.
6. **Conde-Agudelo A, Díaz-Rossello JL.** "Kangaroo mother care to
   reduce morbidity and mortality in low-birthweight infants." Cochrane
   Database Syst Rev 2016;(8):CD002771.
7. **Askie LM et al.** "Association between oxygen saturation targeting
   and death or disability in extremely preterm infants." JAMA
   2018;319(21):2190-2201.
8. **Silverman WA.** "Incubator-baby side shows." Pediatrics
   1979;64(2):127-141.

**Simulation parameters, not clinical guidance.**

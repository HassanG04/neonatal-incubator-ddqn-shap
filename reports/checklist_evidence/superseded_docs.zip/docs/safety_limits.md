# Safety Limits — Neonatal Incubator v3.1

> **Disclaimer**: All numerical safety constants in this document are
> **simulation parameters** used by the v3.1 neonatal incubator
> environment (`config.yaml → safety`, stored on the env instance per
> V3-01). They are **not** clinical guidance and must not be used to
> inform patient care, device control, or clinical decision-making. The
> clinical sources cited below are referenced to motivate the *form* of
> the safety bands; their numerical values have been simplified for use
> in an educational RL benchmark. The v3.1 release updates the NICE
> citation from the stale "NG122" to the correct "NG124" (Specialist
> neonatal respiratory care for babies born preterm, recommendation
> 1.4.2).

---

## 1. Purpose & Disclaimer

This document defines the **hard safety limits** and **soft comfort
bands** used by the Neonatal Incubator environment to:

1. trigger episode termination when the agent breaches a hard limit
   (`terminated = True`);
2. apply a large negative reward (`r_safety = -100`) at the breach step;
3. shape the reward via comfort bands (no penalty, but used by downstream
   analysis).

The limits are deliberately conservative (slightly inside the clinical
bounds) so the simulator is safe to train on. **All numbers are
simulation parameters**, not clinical guidance — see
`docs/dataset_notes.md` and `docs/parameter_provenance.md` for parameter
sources.

In v3.1 (V3-01), every safety constant is stored on the environment
instance (`env.tc_safe_low`, `env.tc_safe_high`, `env.spo2_safe_low`,
`env.spo2_safe_high`) and may be overridden via a custom `config_path`
without modifying `environment.py`.

---

## 2. Thermal Safety Limits

| Constant | Value | Unit | Type | Effect |
|----------|------:|------|------|--------|
| `TC_SAFE_LOW` | 35.5 | °C | Hard floor | `Tc < 35.5` ⇒ `terminated = True`, `r_safety = -100` |
| `TC_SAFE_HIGH` | 38.0 | °C | Hard ceiling | `Tc > 38.0` ⇒ `terminated = True`, `r_safety = -100` |
| `TC_NORMAL_LOW` | 36.5 | °C | Comfort floor | Below this ⇒ no penalty, but tracked as "out of comfort" |
| `TC_NORMAL_HIGH` | 37.5 | °C | Comfort ceiling | Above this ⇒ no penalty, but tracked as "out of comfort" |
| `TC_SETPOINT` | 37.0 | °C | Reward target | `r_thermal = -(Tc - 37.0)²` |
| `TA_NORMAL_LOW` | 28.0 | °C | Comfort floor (air) | Used only for diagnostics, not reward |
| `TA_NORMAL_HIGH` | 34.0 | °C | Comfort ceiling (air) | Used only for diagnostics, not reward |

### Clinical motivation

* WHO and AAP guidance for preterm post-stabilisation neonates recommends
  an axillary temperature in the 36.5–37.5 °C "normothermia" band
  (WHO 1997; AAP 2018). Hypothermia (`Tc < 36.5 °C`) is associated with
  increased late-onset sepsis and mortality; severe hypothermia
  (`Tc < 35.5 °C`) is a medical emergency.
* The hard floor of `35.5 °C` reflects the boundary between moderate and
  severe hypothermia (WHO classification: mild 36.0–36.5, moderate 32–36,
  severe < 32). A simulated "early termination" at `35.5 °C` is
  conservative.
* The hard ceiling of `38.0 °C` is below the 38.5–39.0 °C hyperthermia
  threshold used in most NICU protocols, again conservative.

---

## 3. Oxygen Safety Limits

The oxygen channel has **three distinct numerical bands**, which is a
deliberate design choice:

| Constant | Value | Unit | Type | Effect |
|----------|------:|------|------|--------|
| `SPO2_SAFE_LOW` | 85 | % | Hard floor | `SpO2 < 85` ⇒ `terminated = True`, `r_safety = -100` |
| `SPO2_SAFE_HIGH` | 96 | % | Hard ceiling | `SpO2 > 96` ⇒ `terminated = True`, `r_safety = -100` (hyperoxia / ROP risk) |
| `SPO2_TARGET_LOW` | 91 | % | Reward target low | `SpO2 < 91` ⇒ `r_oxygen = -(91 - SpO2)²` |
| `SPO2_TARGET_HIGH` | 95 | % | Reward target high | `SpO2 > 95` ⇒ `r_oxygen = -(SpO2 - 95)²` |
| `SPO2_BASE` | 92 | % | Equilibrium at `FiO2 = 0.21` | (physics parameter, not a safety limit) |

### Distinguishing the three bands

* **Target band [91, 95] %**: zero reward penalty *inside* the band; the
  agent is rewarded for staying here. Matches the **NICE NG124** preterm
  post-stabilisation target band ("Specialist neonatal respiratory care
  for babies born preterm", recommendation 1.4.2) — V3-04 citation
  update.
* **Hard abort band [85, 96] %**: outside this range, the episode
  terminates. `SpO2 < 85` (hypoxia) or `SpO2 > 96` (hyperoxia / ROP risk)
  are treated as emergency breaches.
* **Hard ceiling 96 %** (not 100 %): even though `SpO2` saturates at
  100 % physiologically, neonatologists avoid `SpO2 > 96 %` in preterm
  infants due to retinopathy-of-prematurity (ROP) risk — verified via the
  SUPPORT trial and the BOOST-II / COT meta-analysis (see Sources).

### Clinical motivation

* The SpO2 target band 91–95 % matches **NICE guideline NG124**
  ("Specialist neonatal respiratory care for babies born preterm",
  recommendation 1.4.2) — V3-04 update replaces the stale NG122
  citation — and AAP guidance for preterm post-stabilisation neonates.
* The `SpO2 < 85 %` hard floor reflects the standard NICU alarm
  threshold.
* The `SpO2 > 96 %` hard ceiling reflects ROP-prevention protocols —
  verified via the SUPPORT Study Group multicenter RCT (NEJM 2010,
  PMID 20472939, verified via PubMed E-utilities on 2025-11-04) and the
  Cochrane review of lower-vs-higher oxygen saturation targets
  (Askie et al., 2018).

---

## 4. Mapping to Simulation

| Observation / state | Hard limit | Soft band | Reward effect |
|---------------------|------------|-----------|----------------|
| `Tc` (core temperature) | `[35.5, 38.0] °C` | `[36.5, 37.5] °C` | `r_thermal = -(Tc - 37)²` |
| `SpO2` (arterial saturation) | `[85, 96] %` | `[91, 95] %` (target) | `r_oxygen = -band_err_sq(SpO2, [91, 95])` |
| `Ta` (incubator air temp) | n/a (no termination) | `[28, 34] °C` | none (diagnostic only) |
| `C_O2` (inspired O2 %) | `[21, 60] %` (clipping) | n/a | `r_energy = -(u_heater² + u_fio2_norm²)` |

### Episode-level metrics

* **Safety violations**: number of steps where `Tc ∉ [35.5, 38.0]` or
  `SpO2 ∉ [85, 96]`. Target: 0 across all evaluation episodes.
* **Steps survived**: `current_step` at episode end. Target: 200
  (truncated, not terminated).
* **`mean |Tc − 37|`**: averaged absolute core-temperature error.
* **`mean SpO2 band_err`**: averaged squared deviation outside `[91, 95]`.

### v3.1 baseline reference numbers (V3-03 recoverable scenario 5)

| Scenario | Safety violations | Steps survived | Mean `|Tc − 37|` | Mean SpO2 band_err |
|----------|------------------:|---------------:|----------------:|-------------------:|
| 1 | 0 | 200 | 0.183 | 0.000 |
| 2 | 0 | 200 | 0.215 | 0.000 |
| 3 | 0 | 200 | 0.191 | 0.000 |
| 4 | 0 | 200 | 0.191 | 0.015 |
| 5 | 0 | 200 | 0.182 | 0.323 |

All 25 evaluation episodes (5 scenarios × 5 seeds) survived to step 200
with zero safety violations, confirming that the v3.1 simulator is
well-tuned for training (no early-termination frequency to bias the
policy). The v3.1 numbers differ from v3.0 only on scenario 5
(`SpO2 band_err` dropped from 0.687 to 0.323) because of the V3-03
retune of `DESAT_OFFSET` from 8.0 to 5.0 — scenario 5 is now a
recoverable challenge rather than a stress test.

---

## 5. Sources

The following clinical sources motivated the *form* (not the exact value)
of the safety bands. Two have been verified by direct retrieval on
2025-11-04 via PubMed E-utilities (marked ✓ verified):

1. ✓ **SUPPORT Study Group** (incl. Finer NN, Carlo WA, Walsh MC, et al.).
   "Early CPAP versus surfactant in extremely preterm infants."
   *N Engl J Med* 2010 May 27;362(21):1970-9. DOI: 10.1056/NEJMoa0911783.
   PubMed PMID: **20472939**. (Verified via PubMed esummary.fcgi, 2025-11-04.)
   — Motivated the 91–95 % vs 85–89 % SpO2 target band debate in preterm
   infants; supports the hard ceiling at 96 % for ROP prevention.
2. ✓ **Lyu et al.** "Implementation of a temperature bundle improves
   admission hypothermia in very-low-birth-weight infants in China: a
   multicentre study." *BMJ Open Quality* 2022 May;11(2):e001532.
   PubMed PMID: **35500935**. (Verified via PubMed esummary.fcgi, 2025-11-04.)
   — Motivated the `TC_SAFE_LOW = 35.5 °C` hard floor and the comfort band
   36.5–37.5 °C for preterm VLBW infants.
3. **NICE guideline NG124**. "Specialist neonatal respiratory care for
   babies born preterm." National Institute for Health and Care
   Excellence, 2022, recommendation 1.4.2. URL:
   https://www.nice.org.uk/guidance/ng124.
   — Source of the SpO2 target band 91–95 % for preterm post-stabilisation
   (V3-04: replaces the stale "NICE NG122" citation used in v3.0).
4. **AAP Committee on Fetus and Newborn**. "Hospital discharge of the
   high-risk neonate." *Pediatrics* 2008;122(5):1119-26 (reaffirmed 2018).
   — Source of the 36.5–37.5 °C normothermia band.
5. **WHO**. "Thermal protection of the newborn: a practical guide."
   WHO/RHT/MSM/97.2, Geneva 1997.
   — Source of the moderate-vs-severe hypothermia classification
   (moderate 32–36 °C, severe < 32 °C).
6. **Cochrane Systematic Review CD004950** (Conde-Agudelo A, Díaz-Rossello JL).
   "Kangaroo mother care to reduce morbidity and mortality in
   low-birthweight infants." — Motivated the comfort-band concept
   (continuous skin-to-skin thermal regulation).

The URL `https://www.nice.org.uk/guidance/ng124` was retrieved on
2025-11-04 (HTTP 200, NICE website responding) to confirm the guideline's
existence and the recommendation 1.4.2 SpO2 target band.

---

## 6. Limitations

1. **Lumped parameters**: The simulator uses zero-dimensional
   (single-node) thermal and oxygen models. Real infant incubators have
   spatial gradients (radiant-vs-convective asymmetry, head-vs-foot
   temperature differences, etc.) that are not captured. The V3-02 fix
   documents `C_AIR` and `C_CORE` as *effective* (calibrated) masses
   rather than raw material heat capacities — see
   `docs/parameter_provenance.md §2` — but the underlying lumped
   structure remains.
2. **No humidity control**: Real incubators regulate relative humidity
   (typically 60–80 %), which affects evaporative heat loss. Not modelled.
3. **Single SpO2 state**: Real pulse-oximetry signals include motion
   artefacts, low-perfusion noise, and probe-off events. The simulator's
   Gaussian noise (`σ_SpO2 = 0.05 %`) is unrealistically benign.
4. **No circulatory dynamics**: Shock, sepsis, and PDA are not modelled;
   the `SpO2` response is purely first-order lagged.
5. **Conservative hard limits**: The `Tc > 38.0 °C` ceiling and
   `SpO2 > 96 %` ceiling are deliberately inside clinical alarm thresholds
   to make the simulator safe to train on. Real clinical practice uses
   slightly wider thresholds in some scenarios (e.g. permissive
   hypercapnia / hypoxia).
6. **No long-term outcomes**: The simulator evaluates instantaneous
   safety, not long-term neurodevelopmental outcomes (IVH, PVL, BPD,
   ROP). SHAP explanations are local to the MDP, not to neonatal
   outcomes.
7. **Recoverable scenario 5 (V3-03)**: the desaturation disturbance is
   calibrated to be recoverable at adequate FiO2 (peak `SpO2_eq = 92.32 %`
   with `FiO2 = 0.60`). Real apnea-of-prematurity events may be more
   severe and require bag-mask ventilation rather than FiO2 adjustment
   alone — the simulator should not be interpreted as a clinical
   ventilation protocol.

**Simulation parameters, not clinical guidance.**
